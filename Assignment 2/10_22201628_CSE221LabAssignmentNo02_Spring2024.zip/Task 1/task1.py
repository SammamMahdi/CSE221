input = open("input1.txt", "r")
output = open("output1.txt", "w")
content = input.read()
lines = [i for i in content.split("\n")]
n, target = [int(i) for i in lines[0].split()]


# sub2
def check_sum1(arr, len, s):
    i, f = 0, len - 1
    while i != f:
        if arr[i] + arr[f] == s:
            return [str(i + 1), str(f + 1)]
        elif arr[i] + arr[f] > s:
            f -= 1
        else:
            i += 1
    return "IMPOSSIBLE"


# sub1
def check_sum2(arr, len, s):
    for i in range(len):
        for j in range(len):
            if arr[i] + arr[j] == s:
                return [str(i + 1), str(j + 1)]
    else:
        return "IMPOSSIBLE"


def write_to_file(out, output):
    if type(out) is list:
        output.write(" ".join(out))
    else:
        output.write(out)


arr = [int(i) for i in lines[1].split()]
out1 = check_sum1(arr, n, target)
out2 = check_sum2(arr, n, target)
write_to_file(out1, output)
write_to_file("\n", output)
write_to_file(out2, output)
output.close()
